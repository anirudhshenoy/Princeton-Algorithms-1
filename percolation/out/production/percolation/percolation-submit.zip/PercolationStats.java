import edu.princeton.cs.algs4.StdRandom;

public class PercolationStats {
    private int trials;
    private double[] percolationThresholds;
    private double mean;
    private double stddev;


    public PercolationStats(int n, int t) {
        if (n <= 0 || t <= 0) {
            throw new java.lang.IllegalArgumentException("n and trials have to be > 0");
        }
        trials = t;
        percolationThresholds = new double[trials];
        for (int trial = 0; trial < trials; trial++) {
            Percolation perc = new Percolation(n);
            double totalSites = n * n;
            double openSites;
            int[] rowCol = new int[2];
            while (!perc.percolates()) {
                rowCol = getRandomRowCol(n + 1);
                perc.open(rowCol[0], rowCol[1]);
            }
            openSites = perc.numberOfOpenSites();
            percolationThresholds[trial] = openSites / totalSites;
        }
    }

    private int[] getRandomRowCol(int n) {
        int[] rowCol = new int[2];
        rowCol[0] = StdRandom.uniform(n);
        rowCol[1] = StdRandom.uniform(n);
        while (rowCol[0] == 0) {
            rowCol[0] = StdRandom.uniform(n);
        }
        while (rowCol[1] == 0) {
            rowCol[1] = StdRandom.uniform(n);
        }
        return rowCol;
    }

    public double mean() {
        mean = 0.0;
        for (int trial = 0; trial < trials; trial++) {
            mean += (percolationThresholds[trial] / trials);
        }
        return mean;
    }

    public double stddev() {
        if (trials == 1) {
            return Double.NaN;
        }
        stddev = 0.0;
        for (int trial = 0; trial < trials; trial++) {
            stddev += (Math.pow((percolationThresholds[trial] - mean), 2.0) / (trials - 1));
        }
        stddev = Math.sqrt(stddev);
        return stddev;
    }

    public double confidenceLo() {
        double frac = (1.96 * stddev) / Math.sqrt(trials);
        return (mean - frac);
    }

    public double confidenceHi() {
        double frac = (1.96 * stddev) / Math.sqrt(trials);
        return (mean + frac);
    }

    public static void main(String[] args) {
        PercolationStats p = new PercolationStats(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
        System.out.print("mean = ");
        System.out.println(p.mean());
        System.out.print("stddev = ");
        System.out.println(p.stddev());
        System.out.print("95% Confidence Interval = [");
        System.out.print(p.confidenceLo());
        System.out.print(",");
        System.out.print(p.confidenceHi());
        System.out.println("]");
    }
}
